﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SearchAndSort.DataBase
{
     public class Tbl_News
    {
        public Guid Id { get; set; }
        public string Title { get; set; }
        public string Detail { get; set; }

    }
}